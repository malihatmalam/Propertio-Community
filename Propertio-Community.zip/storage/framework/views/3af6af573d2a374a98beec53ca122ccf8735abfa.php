

<div class="pcoded-navigatio-lavel">Management</div>
<ul class="pcoded-item pcoded-left-item">
    <li class="pcoded-hasmenu">
        <a href="javascript:void(0)">
            <span class="pcoded-micon"><i class="feather icon-grid"></i></span>
            <span class="pcoded-mtext">Managemen Kategori</span>
        </a>
        <ul class="pcoded-submenu">
            <li class=" ">
                <a href="<?php echo e(route('category.index')); ?>">
                    <span class="pcoded-mtext">List Kategori</span>
                </a>
            </li>
            <li class=" ">
                <a href="<?php echo e(route('category.create')); ?>">
                    <span class="pcoded-mtext">Penambahan Kategori</span>
                </a>
            </li>
        </ul>
    </li>
    <li class="pcoded-hasmenu">
        <a href="javascript:void(0)">
            <span class="pcoded-micon"><i class="feather icon-hash"></i></span>
            <span class="pcoded-mtext">Managemen Tag</span>
        </a>
        <ul class="pcoded-submenu">
            <li class=" ">
                <a href="<?php echo e(route('tag.index')); ?>">
                    <span class="pcoded-mtext">List Tag</span>
                </a>
            </li>
            <li class=" ">
                <a href="<?php echo e(route('tag.create')); ?>">
                    <span class="pcoded-mtext">Penambahan Tag</span>
                </a>
            </li>
        </ul>
    </li>
</ul>
<?php /**PATH E:\PROJECK\Project Propertio\Propertio Solution Baru\Propertio-Community\resources\views/layout/cms/sidebar-role/sidebar-admin.blade.php ENDPATH**/ ?>