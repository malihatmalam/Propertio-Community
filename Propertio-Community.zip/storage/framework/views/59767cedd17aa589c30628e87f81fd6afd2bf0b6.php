


<?php $__env->startSection('custom-css'); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<section class="section wb">
     <div class="container">
          <div class="row">
               <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
                    <div class="page-wrapper">
                         <div class="blog-title-area">
                              <ol class="breadcrumb hidden-xs-down">
                              <li class="breadcrumb-item"><a href="#">Home</a></li>
                              
                              <li class="breadcrumb-item"><a href="#"><?php echo e($data->category->name); ?></a></li>
                              <li class="breadcrumb-item active"><?php echo e($data->title); ?></li>
                              </ol>

                              <span class="color-green"><a href="<?php echo e(route('blog.category.list', $data->category->name )); ?>" title=""><?php echo e($data->category->name); ?></a></span>

                              <h3><?php echo e($data->title); ?></h3>

                              <div class="blog-meta big-meta">
                              <small><a href="" title=""><?php echo e($data->date); ?></a></small>
                              <small><a href="" title="">oleh <?php echo e($data->users->userData->fullname); ?></a></small>
                              <small><a href="#" title=""><i class="fa fa-calendar-o"></i> hanya <strong><?php echo e($data->read_duration); ?> menit</strong> untuk dibaca</a></small>
                              </div><!-- end meta -->

                              
                         </div><!-- end title -->

                         <div class="single-post-media">
                              <img src="<?php echo e(asset( $data->image_cover )); ?>" alt="" class="img-fluid">
                         </div><!-- end media -->

                         <div class="blog-content">  
                              <?php echo $data->content; ?>

                         </div><!-- end content -->

                         <div class="blog-title-area">
                              <div class="tag-cloud-single">
                              <span>Tags</span>
                              <?php $__empty_1 = true; $__currentLoopData = $data->tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                              <small><a href="#" title=""><?php echo e($tag->name); ?></a></small>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                  
                              <?php endif; ?>
                              </div><!-- end meta -->

                              
                         </div><!-- end title -->

                         

                         <hr class="invis1">

                         <div class="custombox authorbox clearfix">
                              <h4 class="small-title">Tentang penulis</h4>
                              <div class="row">
                              <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                   <img src="http://propertio-dev.apps.test/data/image/users/<?php echo e($data->users->userData->picture_profile); ?>" alt="" class="img-fluid rounded-circle"> 
                              </div><!-- end col -->

                              <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
                                   <h4><a href="#"><?php echo e($data->users->userData->fullname); ?></a></h4>
                                   

                                   <div class="topsocial">
                                        <a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
                                        <a href="#" data-toggle="tooltip" data-placement="bottom" title="Youtube"><i class="fa fa-youtube"></i></a>
                                        <a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest"></i></a>
                                        <a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
                                        <a href="#" data-toggle="tooltip" data-placement="bottom" title="Instagram"><i class="fa fa-instagram"></i></a>
                                        <a href="#" data-toggle="tooltip" data-placement="bottom" title="Website"><i class="fa fa-link"></i></a>
                                   </div><!-- end social -->

                              </div><!-- end col -->
                              </div><!-- end row -->
                         </div><!-- end author-box -->

                         

                         
                    </div><!-- end page-wrapper -->
               </div><!-- end col -->

               <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                    <div class="sidebar">
                         <div class="widget">
                              <h2 class="widget-title">Pencarian</h2>
                              <form class="form-inline search-form" action="<?php echo e(route('blog.cari')); ?>" method="get">
                                   <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Cari artikel yuk ...">
                                   </div>
                              <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                              </form>
                         </div><!-- end widget -->

                         

                         <div class="widget">
                              <h2 class="widget-title">Popular Categories</h2>
                              <div class="link-widget">
                              <ul id="category">
                                   
                              </ul>
                              </div><!-- end link-widget -->
                         </div><!-- end widget -->

                    </div><!-- end sidebar -->
               </div><!-- end col -->
          </div><!-- end row -->
     </div><!-- end container -->
</section>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom-js'); ?>
<script type="text/javascript">
     $(document).ready(function() {
 
         $.ajax({
             type: 'GET',
             url: '/category_footer',
             success: function(data) {
                 //append to table
                 if (data.category) {
                     data.category.forEach(function(item, index) {
                         $("#category").append(createTr(item));
                     });
                 }
             },
             error: function(data) {}
         });
 
 
 
         function createTr(item) {
             var tr = 
             '<li>' +
               '<a href="/category/' + item.name + '/list-post" id="category-1">' + item.name + '<span>' + item.articles_count + '</span> </a>' +
             '</li>'

             return tr;
         }
 
     });
 </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.public.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECK\Project Propertio\Propertio Solution Baru\Propertio-Community\resources\views/page/article/public/detail.blade.php ENDPATH**/ ?>