


<?php $__env->startSection('custom-css'); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    
    
    

    
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="section-title">
                        <h3 class="color-aqua"><a href="blog-category-01.html" title="">Properti</a></h3>
                    </div><!-- end title -->

                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <?php $__currentLoopData = $data_properti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="blog-box">
                                <div class="post-media">
                                    <a href="<?php echo e(route('blog.isi', $post->slug )); ?>" title="">
                                        <img src="<?php echo e(asset( $post->image_cover )); ?>" alt="" class="img-fluid">
                                        <div class="hovereffect">
                                            <span></span>
                                        </div><!-- end hover -->
                                    </a>
                                </div><!-- end media -->
                                <div class="blog-meta big-meta">
                                    <h4><a href="<?php echo e(route('blog.isi', $post->slug )); ?>" title=""><?php echo e($post->title); ?></a></h4>
                                    <p><?php echo substr($post->content, 0, 197) . '...'; ?></p>
                                    <small><a href="" title=""><?php echo e($post->category->name); ?></a></small>
                                    <small><a href="" title=""><?php echo e($post->date); ?></a></small>
                                    <small><a href="" title="">oleh <?php echo e($post->users->userData->fullname); ?></a></small>
                                </div><!-- end meta -->
                            </div><!-- end blog-box -->
                            
                            <hr class="invis">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div><!-- end col -->
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            
                            <h5>
                                <a href="<?php echo e(route('blog.category.list', $c_properti->name )); ?>"> <strong>Lihat lebih banyak</strong></a>
                            </h5>
                        </div>
                    </div><!-- end row -->
                </div><!-- end col -->

                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="section-title">
                        <h3 class="color-pink"><a href="blog-category-01.html" title="">Arsitektur</a></h3>
                    </div><!-- end title -->
                    <div class="row">
                        <?php $__currentLoopData = $data_arsitektur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <div class="blog-box">
                                <div class="post-media">
                                    <a href="<?php echo e(route('blog.isi', $post->slug )); ?>" title="">
                                        <img src="<?php echo e(asset( $post->image_cover )); ?>" alt="" class="img-fluid">
                                        <div class="hovereffect">
                                            <span></span>
                                        </div><!-- end hover -->
                                    </a>
                                </div><!-- end media -->
                                <div class="blog-meta big-meta">
                                    <h4><a href="<?php echo e(route('blog.isi', $post->slug )); ?>" title=""><?php echo e($post->title); ?></a></h4>
                                    
                                    <small><a href="" title=""><?php echo e($post->category->name); ?></a></small>
                                    <small><a href="" title=""><?php echo e($post->date); ?></a></small>
                                    
                                </div><!-- end meta -->
                            </div><!-- end blog-box -->
                            
                            <hr class="invis">
                        </div><!-- end col -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            
                            <h5>
                                <a href="<?php echo e(route('blog.category.list', $c_arsitektur->name )); ?>"> <strong>Lihat lebih banyak</strong></a>
                            </h5>
                        </div>
                    </div><!-- end row -->
                </div><!-- end col -->
            </div><!-- end row -->

            <hr class="invis1">

            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="banner-spot clearfix">
                        <div class="banner-img">
                            <img src="upload/banner_01.jpg" alt="" class="img-fluid">
                        </div><!-- end banner-img -->
                    </div><!-- end banner -->
                </div><!-- end col -->
            </div><!-- end row -->

            <hr class="invis1">

            <div class="row">
                <div class="col-lg-9">
                    <div class="blog-list clearfix">
                        <div class="section-title">
                            <h3 class="color-green"><a href="blog-category-01.html" title="">Keuangan</a></h3>
                        </div><!-- end title -->

                        <?php $__currentLoopData = $data_keuangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="blog-box row">
                            <div class="col-md-4">
                                <div class="post-media">
                                    <a href="<?php echo e(route('blog.isi', $post->slug )); ?>" title="">
                                        <img src="<?php echo e(asset( $post->image_cover )); ?>" alt="" class="img-fluid">
                                        <div class="hovereffect"></div>
                                    </a>
                                </div><!-- end media -->
                            </div><!-- end col -->

                            <div class="blog-meta big-meta col-md-8">
                                <h4><a href="<?php echo e(route('blog.isi', $post->slug )); ?>" title=""><?php echo e($post->title); ?></a></h4>
                                <p><?php echo substr($post->content, 0, 197) . '...'; ?></p>
                                <small><a href="" title=""><?php echo e($post->category->name); ?></a></small>
                                <small><a href="" title=""><?php echo e($post->date); ?></a></small>
                                <small><a href="" title="">oleh <?php echo e($post->users->userData->fullname); ?></a></small>
                            </div><!-- end meta -->
                        </div><!-- end blog-box -->

                        <hr class="invis">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <hr class="invis">
                            <h5>
                                <a href="<?php echo e(route('blog.category.list', $c_keuangan->name )); ?>"> <strong>Lihat lebih banyak</strong></a>
                            </h5>
                        </div>
                    </div><!-- end blog-list -->

                    <hr class="invis">

                    <div class="blog-list clearfix">
                        <div class="section-title">
                            <h3 class="color-red"><a href="blog-category-01.html" title="">Lifestyle</a></h3>
                        </div><!-- end title -->

                        <?php $__currentLoopData = $data_lifestyle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <div class="blog-box row">
                            <div class="col-md-4">
                                <div class="post-media">
                                    <a href="<?php echo e(route('blog.isi', $post->slug )); ?>" title="">
                                        <img src="<?php echo e(asset( $post->image_cover )); ?>" alt="" class="img-fluid">
                                        <div class="hovereffect"></div>
                                    </a>
                                </div><!-- end media -->
                            </div><!-- end col -->

                            <div class="blog-meta big-meta col-md-8">
                                <h4><a href="<?php echo e(route('blog.isi', $post->slug )); ?>" title=""><?php echo e($post->title); ?></a></h4>
                                <p><?php echo substr($post->content, 0, 197) . '...'; ?></p>
                                <small><a href="" title=""><?php echo e($post->category->name); ?></a></small>
                                <small><a href="" title=""><?php echo e($post->date); ?></a></small>
                                <small><a href="" title="">oleh <?php echo e($post->users->userData->fullname); ?></a></small>
                            </div><!-- end meta -->
                        </div><!-- end blog-box -->

                        <hr class="invis">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            
                            <h5>
                                <a href="<?php echo e(route('blog.category.list', $c_lifestyle->name )); ?>"> <strong>Lihat lebih banyak</strong></a>
                            </h5>
                        </div>
                    </div><!-- end blog-list -->
                </div><!-- end col -->

                <div class="col-lg-3">
                    <div class="section-title">
                        <h3 class="color-yellow"><a href="blog-category-01.html" title="">Ide Kreatif</a></h3>
                    </div><!-- end title -->

                    <?php $__currentLoopData = $data_ide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <div class="blog-box">
                        <div class="post-media">
                            <a href="<?php echo e(route('blog.isi', $post->slug )); ?>" title="">
                                <img src="<?php echo e(asset( $post->image_cover )); ?>" alt="" class="img-fluid">
                                <div class="hovereffect">
                                    <span class="hovereffect"></span>
                                </div><!-- end hover -->
                            </a>
                        </div><!-- end media -->
                        <div class="blog-meta">
                            <h4><a href="<?php echo e(route('blog.isi', $post->slug )); ?>" title=""><?php echo e($post->title); ?></a></h4>
                            <small><a href="" title=""><?php echo e($post->category->name); ?></a></small>
                            <small><a href="" title=""><?php echo e($post->date); ?></a></small>
                        </div><!-- end meta -->
                    </div><!-- end blog-box -->

                    <hr class="invis">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        
                        <h5>
                            <a href="<?php echo e(route('blog.category.list', $c_ide->name )); ?>"> <strong>Lihat lebih banyak</strong></a>
                        </h5>
                    </div>

                    <hr class="invis">

                    <div class="section-title">
                        <h3 class="color-grey"><a href="blog-category-01.html" title="">Budaya</a></h3>
                    </div><!-- end title -->

                    <?php $__currentLoopData = $data_budaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <div class="blog-box">
                        <div class="post-media">
                            <a href="<?php echo e(route('blog.isi', $post->slug )); ?>" title="">
                                <img src="<?php echo e(asset( $post->image_cover )); ?>" alt="" class="img-fluid">
                                <div class="hovereffect">
                                    <span></span>
                                </div><!-- end hover -->
                            </a>
                        </div><!-- end media -->
                        <div class="blog-meta">
                            <h4><a href="<?php echo e(route('blog.isi', $post->slug )); ?>" title=""><?php echo e($post->title); ?></a></h4>
                            <small><a href="" title=""><?php echo e($post->category->name); ?></a></small>
                            <small><a href="" title=""><?php echo e($post->date); ?></a></small>
                        </div><!-- end meta -->
                    </div><!-- end blog-box -->

                    <hr class="invis">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        
                        <h5>
                            <a href="<?php echo e(route('blog.category.list', $c_budaya->name )); ?>"> <strong>Lihat lebih banyak</strong></a>
                        </h5>
                    </div>
                </div><!-- end col -->
            </div><!-- end row -->

            <hr class="invis1">

            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="banner-spot clearfix">
                        <div class="banner-img">
                            <img src="upload/banner_02.jpg" alt="" class="img-fluid">
                        </div><!-- end banner-img -->
                    </div><!-- end banner -->
                </div><!-- end col -->
            </div><!-- end row -->
        </div><!-- end container -->
    </section>
    
<?php $__env->stopSection(); ?>




<?php $__env->startSection('custom-js'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.public.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECK\Project Propertio\Propertio Solution Baru\Propertio-Community\resources\views/page/homepage/homepage.blade.php ENDPATH**/ ?>