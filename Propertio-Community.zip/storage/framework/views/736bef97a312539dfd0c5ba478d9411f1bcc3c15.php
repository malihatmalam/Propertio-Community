<div class="pcoded-inner-navbar main-menu" style="background: #07895b;">

    <?php switch(auth()->user()->role):
        case ('ADMIN'): ?>
            <?php echo $__env->make('layout.cms.sidebar-role.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('EMPLOYEE'): ?>
            <?php echo $__env->make('layout.cms.sidebar-role.sidebar-consultant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
        <?php break; ?>

        <?php default: ?>
            <?php echo $__env->make('layout.cms.sidebar-role.sidebar-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endswitch; ?>

</div>
<?php /**PATH E:\PROJECK\Project Propertio\Propertio Solution Baru\Propertio-Community\resources\views/layout/cms/sidebar.blade.php ENDPATH**/ ?>