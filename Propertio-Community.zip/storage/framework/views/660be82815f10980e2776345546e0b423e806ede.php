<!DOCTYPE html>
<html lang="id">


<?php echo $__env->make('layout.cms.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body>
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">

            
            <?php echo $__env->make('layout.cms.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            

            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">

                    <nav class="pcoded-navbar" style="background: #07895b;">
                    
                    <?php echo $__env->make('layout.cms.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    </nav>

                    
                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">
                                    <?php echo $__env->yieldContent('content'); ?>
                                </div>

                                <div id="styleSelector">

                                </div>
                            </div>
                        </div>
                    </div>
                    

                </div>
            </div>
        </div>
    </div>

    
    <?php echo $__env->make('layout.cms.scripts-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    
    <?php echo $__env->yieldContent('custom-js'); ?>
    

</body>

</html><?php /**PATH E:\PROJECK\Project Propertio\Propertio Solution Baru\Propertio-Community\resources\views/layout/cms/master.blade.php ENDPATH**/ ?>