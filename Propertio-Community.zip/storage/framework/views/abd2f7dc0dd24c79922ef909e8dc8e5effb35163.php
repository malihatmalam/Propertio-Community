


<?php $__env->startSection('custom-css'); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="page-title">
     <div class="container">
         <div class="row">
             <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                 <h2><i class="fa fa-th"></i> Management Artikel</h2>
             </div><!-- end col -->
             <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                 <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="#">Home</a></li>
                     <li class="breadcrumb-item active">Artikel</li>
                 </ol>
             </div><!-- end col -->                    
         </div><!-- end row -->
     </div><!-- end container -->
</div><!-- end page-title -->
<section class="section">
     <div class="container">
          <?php if(Session::has('success')): ?>
          <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                         <div class="alert alert-success" role="alert">
                              <strong>Berhasil ! </strong><?php echo e(Session('success')); ?>

                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                   <span aria-hidden="true">&times;</span>
                              </button>
                         </div>
               </div>
          </div>
          <?php endif; ?>
         <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                   <div class="page-wrapper">
                         <a href="<?php echo e(route('post.create')); ?>" class="btn btn-info btn-sm">Tambah Artikel</a>
                         <br><br>
                   </div>
               </div>
         </div>
         <div class="row">
             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                 <div class="page-wrapper">
                    <table class="table table-striped table-hover table-sm table-bordered">
                         <thead>
                              <tr>
                                   <th>No</th>
                                   <th>Nama Post</th>
                                   <th>Kategori</th>
                                   <th>Daftar Tags</th>
                                   <th>Creator</th>
                                   <th>Thumbnail</th>
                                   <th>Action</th>
                              </tr>
                         </thead>
                         <tbody>
                              <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                   <td><?php echo e($result + $post->firstitem()); ?></td>
                                   <td><?php echo e($hasil->title); ?></td>
                                   <td><?php echo e($hasil->category->name); ?></td>
                                   <td>
                                        <?php $__currentLoopData = $hasil->tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul>
                                             <h6><span class="badge badge-info"><?php echo e($tag->name); ?></span></h6>
                                        </ul>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
                                   </td>
                                   <td><?php echo e($hasil->users->userData->fullname); ?></td>
                                   <td><img src="<?php echo e(asset( $hasil->image_cover )); ?>" class="img-fluid" style="width:100px"></td>
                                   <td>
                                        <form action="<?php echo e(route('post.destroy', $hasil->id )); ?>" method="POST">
                                             <?php echo csrf_field(); ?>
                                             <?php echo method_field('delete'); ?>
                                        <a href="<?php echo e(route('post.edit', $hasil->id )); ?>" class="btn btn-primary btn-sm">Edit</a>
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                   </td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                         </tbody>
                    </table>
                    <div class="row">
                         <div class="col-md-12">
                             <?php echo e($post->links('vendor.pagination.default')); ?>

                         </div>
                     </div>
                 </div><!-- end page-wrapper -->
             </div><!-- end col -->
         </div><!-- end row -->
     </div><!-- end container -->
 </section>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom-js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.public.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECK\Project Propertio\Propertio Solution Baru\Propertio-Community\resources\views/page/article/public/posting/index.blade.php ENDPATH**/ ?>