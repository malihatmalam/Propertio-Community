


<?php $__env->startSection('custom-css'); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <!-- Page-header start -->
    <div class="page-header">
        <div class="row align-items-end">
            <div class="col-lg-8">
                <div class="page-header-title">
                    <div class="d-inline">
                        <h4>Daftar Kategori Artikel</h4>
                        <span>Management list kategori artikel.</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="index-1.htm"> <i class="feather icon-home"></i> </a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">Artikel</a>
                        </li>
                        <li class="breadcrumb-item"><a href="">Kategori</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <!-- Page-body start -->
    <div class="page-body">
        <!-- Input group card start -->
        <div class="card">
            <div class="card-block">
                <!-- Basic group add-ons start -->
                <div class="m-b-20">
                    <h4 class="sub-title">Tabel Kategori Artikel</h4>
                    <div class="row">

                        <?php if(Session::has('success')): ?>
                        <div class="col-sm-12 col-md-12 col-xl-12">
                            <div class="alert alert-success background-success">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <i class="icofont icofont-close-line-circled text-white"></i>
                                </button>
                                <strong>Berhasil !</strong> <?php echo e(Session('success')); ?>

                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="col-sm-12 col-md-12 col-xl-12 align-self-end">
                            <a href="<?php echo e(route('category.create')); ?>" class="btn btn-primary btn-sm">Tambah Kategori</a>
                            <br><br>
                        </div>

                        <div class="col-sm-12 col-md-12 col-xl-12">
                            <table class="table table-striped table-hover table-sm table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Kategori</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($result + $category->firstitem()); ?></td>
                                        <td><?php echo e($hasil->name); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('category.destroy', $hasil->id )); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                            <a href="<?php echo e(route('category.edit', $hasil->id )); ?>" class="btn btn-primary btn-sm">Edit</a>
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                                </tbody>
                            </table>
                            <?php echo e($category->links('vendor.pagination.bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
                <!-- Basic group add-ons end -->
            </div>
        </div>
        <!-- Input group card end -->
    </div>
    <!-- Page-body end -->
<?php $__env->stopSection(); ?>




<?php $__env->startSection('custom-js'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.cms.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECK\Project Propertio\Propertio Solution Baru\Propertio-Community\resources\views/page/article/cms/category/index.blade.php ENDPATH**/ ?>