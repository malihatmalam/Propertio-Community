<!DOCTYPE html>
<html lang="id">


<?php echo $__env->make('layout.public.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body>
    <!-- LOADER -->
    <div id="preloader">
        <img class="preloader" src="<?php echo e(asset('assets/public/images/loader.gif')); ?>" alt="">
    </div><!-- end loader -->
    <!-- End LOADER -->

    <div id="wrapper">

        
        <?php echo $__env->make('layout.public.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
        <?php echo $__env->yieldContent('content'); ?>
        

        
        <?php echo $__env->make('layout.public.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        


        
        <?php echo $__env->make('layout.public.script-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
        <?php echo $__env->yieldContent('custom-js'); ?>
        

    </div>
</body>

</html><?php /**PATH E:\PROJECK\Project Propertio\Propertio Solution Baru\Propertio-Community\resources\views/layout/public/master.blade.php ENDPATH**/ ?>